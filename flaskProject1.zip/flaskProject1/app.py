from flask import Flask, redirect, url_for,  render_template
from flask import request
from flask import session

app = Flask(__name__)
app.secret_key='123'


@app.route('/')
@app.route('/index.html')
def index_func():
    return render_template('index.html')

@app.route('/form.html')
def contact_me():
    return render_template('form.html')

@app.route('/users.html')
def users_list():
    return render_template('users.html')

@app.route('/assignment8.html')
def assignment8():
    return render_template('assignment8.html', first_name='Hadar' , last_name='Greener', hobbies_pref=['movies','dancing','paint'])

@app.route('/extendassignment8.html')
def extendassignment8():
    return render_template('extendassignment8.html')

@app.route('/assignment9', methods=['GET', 'POST'])
def assignment9():
    name = 'Friend'
    Users = {"Roni": "Rabinovich", "Adi": "Danovich", "Hagar": "Cohen", "Daniela": "Ovadia", "David": "Dvash"}
    username = ' '
    logged_in = True

    if request.method == 'GET':
        if 'name' in request.args:
            name = request.args['name']

    if request.method == 'POST':
        username = request.form['username']
        session['logged_in'] = True
        session['username'] = username


    return render_template('assignment9.html',
                           request_method=request.method,
                           name = name,
                           Users = Users,
                           username = username)

@app.route('/log_out')
def log_out():
    session.pop('username')
    session['logged_in'] = False
    return redirect('/assignment9')


if __name__ == '__main__':
    app.run(debug=True)
